package com.babariviere.sms.status;

/**
 * Created by Joan Pablo on 4/17/2018.
 */

public enum  SmsStatus {
    SMS_RECEIVED,
    SMS_SENT
}
